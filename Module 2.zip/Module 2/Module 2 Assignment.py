#!/usr/bin/env python
# coding: utf-8

# import pandas as pd
# import csv
# import zipfile
# import os
# 
# # Importing the provided salary data from the Kaggle link with adjusted parameters
# kaggle_url = "https://www.kaggle.com/code/itshorus/sf-salary"
# salary_data = pd.read_csv(kaggle_url, delimiter=',', encoding='latin1')
# 
# # Function to get employee details by name
# def get_employee_details(name):
#     employee = salary_data[salary_data['EmployeeName'] == name]
#     if not employee.empty:
#         return employee.to_dict(orient='records')[0]
#     return None
# 
# # Validate if the file contains data from Kaggle
# def validate_kaggle_data(file_path):
#     with open(file_path, 'r') as file:
#         first_line = file.readline()
#         if kaggle_url in first_line:
#             return True
#         return False
# 
# # Processing salary data using a Python dictionary
# salary_dict = salary_data.set_index('EmployeeName').T.to_dict()
# 
# # Error handling for employee details function
# try:
#     employee_names = salary_data['EmployeeName'].unique()
#     for employee_name in employee_names:
#         employee_details = get_employee_details(employee_name)
#         if employee_details:
#             print(f"Employee Details for {employee_name}: {employee_details}")
#         else:
#             print(f"Employee with name {employee_name} not found.")
# except Exception as e:
#     print(f"An error occurred: {e}")
# 
# # Exporting employee details to a CSV file within a zipped folder
# output_folder = "Employee Profile"
# os.makedirs(output_folder, exist_ok=True)
# 
# output_file = f"{output_folder}/employee_details.csv"
# with open(output_file, mode='w', newline='') as file:
#     writer = csv.DictWriter(file, fieldnames=salary_data.columns)
#     writer.writeheader()
#     for _, row in salary_data.iterrows():
#         writer.writerow(row.to_dict())
# 
# zip_file = f"{output_folder}.zip"
# with zipfile.ZipFile(zip_file, 'w') as zipf:
#     zipf.write(output_file, os.path.basename(output_file))
# 
# print(f"Employee details exported to {zip_file}")
# 
# # Validate if the exported file contains data from Kaggle
# if validate_kaggle_data(output_file):
#     print("Exported file contains data from Kaggle.")
# else:
#     print("Exported file does not contain data from Kaggle.")
