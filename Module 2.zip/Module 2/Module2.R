R
# Unzip the folder
unzip("Employee Profile.zip")

# Read the CSV file
employee_data <- read.csv("Employee Profile/employee_details.csv")

# Display the data
print(employee_data)
